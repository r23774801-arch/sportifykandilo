<?php
header('Content-Type: application/json; charset=UTF-8');
require_once 'koneksi.php';
require_once 'auth.php';

$action = $_GET['action'] ?? '';

function send_json($payload, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ensure_registration_table($conn) {
    // Tabel yang sudah ada di database versi lama memiliki kolom:
    // id, event_id, nama_tim, nama_pemenang, status_pendaftaran, created_at.
    // Jangan mengganti/menghapus kolom tersebut. Tambahkan kolom yang dibutuhkan
    // oleh formulir Gabung agar database lama tetap kompatibel.
    $create = "CREATE TABLE IF NOT EXISTS event_registrations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_id INT NOT NULL,
        nama_tim VARCHAR(150) NULL,
        nama_pemenang VARCHAR(255) NULL,
        status_pendaftaran VARCHAR(30) NOT NULL DEFAULT 'Menunggu',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_event_id (event_id),
        INDEX idx_status_pendaftaran (status_pendaftaran)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    if (!$conn->query($create)) {
        send_json(["status" => "error", "message" => "Tabel event_registrations tidak dapat dibuat: " . $conn->error], 500);
    }

    // Pastikan kolom baru tersedia. Kolom lama tidak diubah.
    $required = [
        'nama_lengkap' => "VARCHAR(150) NULL",
        'alias_nama' => "VARCHAR(100) NULL",
        'instagram' => "VARCHAR(150) NULL",
        'whatsapp' => "VARCHAR(50) NULL",
        'foto_path' => "VARCHAR(255) NULL",
        'status' => "VARCHAR(30) NOT NULL DEFAULT 'Menunggu'",
        'updated_at' => "TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];

    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM event_registrations");
    if (!$res) send_json(["status" => "error", "message" => "Gagal membaca struktur event_registrations: " . $conn->error], 500);
    while ($row = $res->fetch_assoc()) $cols[strtolower($row['Field'])] = true;

    foreach ($required as $name => $definition) {
        if (!isset($cols[strtolower($name)])) {
            if (!$conn->query("ALTER TABLE event_registrations ADD COLUMN `$name` $definition")) {
                send_json(["status" => "error", "message" => "Kolom `$name` belum tersedia dan gagal ditambahkan: " . $conn->error], 500);
            }
        }
    }

    // Migrasikan data lama jika ada, tanpa menghapus kolom lama.
    $conn->query("UPDATE event_registrations SET nama_lengkap = COALESCE(NULLIF(nama_lengkap,''), nama_tim) WHERE nama_tim IS NOT NULL AND nama_tim <> ''");
    $conn->query("UPDATE event_registrations SET status = COALESCE(NULLIF(status,''), status_pendaftaran, 'Menunggu') WHERE status IS NULL OR status = ''");
}
ensure_registration_table($conn);

// Public: ambil event yang dibuat Admin untuk pilihan pendaftaran.
if ($action === 'get_registration_events' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT id, nama_event, cabang_olahraga, tanggal_pelaksanaan, jam_pelaksanaan, lokasi, status
            FROM events
            WHERE LOWER(COALESCE(status,'Buka')) NOT IN ('selesai','dibatalkan')
            ORDER BY tanggal_pelaksanaan ASC, jam_pelaksanaan ASC, id DESC";
    $result = $conn->query($sql);
    if (!$result) send_json(["status" => "error", "message" => $conn->error], 500);
    $events = [];
    while ($row = $result->fetch_assoc()) $events[] = $row;
    send_json($events);
}

// Public: user mengirim formulir Gabung. Tidak membutuhkan password.
if ($action === 'register_event' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim((string)($_POST['nama_lengkap'] ?? ''));
    $alias = trim((string)($_POST['alias_nama'] ?? ''));
    $instagram = trim((string)($_POST['instagram'] ?? ''));
    $whatsapp = trim((string)($_POST['whatsapp'] ?? ''));
    $event_id = (int)($_POST['event_id'] ?? 0);

    if ($nama === '' || $whatsapp === '' || $event_id < 1) {
        send_json(["status" => "error", "message" => "Nama lengkap, WhatsApp, foto, dan event wajib diisi."], 400);
    }

    $eventStmt = $conn->prepare("SELECT id, nama_event, status FROM events WHERE id = ? LIMIT 1");
    if (!$eventStmt) send_json(["status" => "error", "message" => $conn->error], 500);
    $eventStmt->bind_param('i', $event_id);
    $eventStmt->execute();
    $event = $eventStmt->get_result()->fetch_assoc();
    $eventStmt->close();
    if (!$event) send_json(["status" => "error", "message" => "Event yang dipilih tidak ditemukan."], 404);
    if (in_array(strtolower((string)$event['status']), ['selesai','dibatalkan'], true)) {
        send_json(["status" => "error", "message" => "Event tersebut sudah tidak menerima pendaftaran."], 400);
    }

    if (!isset($_FILES['foto']) || $_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        send_json(["status" => "error", "message" => "Pas Foto wajib diunggah."], 400);
    }

    $file = $_FILES['foto'];
    if ($file['size'] > 3 * 1024 * 1024) send_json(["status" => "error", "message" => "Ukuran foto maksimal 3MB."], 400);
    $mime = function_exists('mime_content_type') ? mime_content_type($file['tmp_name']) : $file['type'];
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($allowed[$mime])) send_json(["status" => "error", "message" => "Foto harus JPG, PNG, atau WEBP."], 400);

    // Cegah pendaftaran ganda pada event yang sama berdasarkan nomor WhatsApp.
    $dup = $conn->prepare("SELECT id FROM event_registrations WHERE event_id = ? AND whatsapp = ? AND status <> 'Ditolak' LIMIT 1");
    if ($dup) {
        $dup->bind_param('is', $event_id, $whatsapp);
        $dup->execute();
        if ($dup->get_result()->num_rows > 0) {
            $dup->close();
            send_json(["status" => "error", "message" => "Nomor WhatsApp tersebut sudah terdaftar pada event ini."], 409);
        }
        $dup->close();
    }

    $uploadDir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'registrasi';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true)) {
        send_json(["status" => "error", "message" => "Folder upload foto tidak dapat dibuat."], 500);
    }
    $filename = 'registrasi_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $allowed[$mime];
    $destination = $uploadDir . DIRECTORY_SEPARATOR . $filename;
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        send_json(["status" => "error", "message" => "Foto gagal disimpan di server."], 500);
    }
    $photoPath = 'uploads/registrasi/' . $filename;

    $stmt = $conn->prepare("INSERT INTO event_registrations (event_id, nama_lengkap, alias_nama, instagram, whatsapp, foto_path, status) VALUES (?, ?, ?, ?, ?, ?, 'Menunggu')");
    if (!$stmt) {
        @unlink($destination);
        send_json(["status" => "error", "message" => "Gagal menyiapkan pendaftaran: " . $conn->error], 500);
    }
    $stmt->bind_param('isssss', $event_id, $nama, $alias, $instagram, $whatsapp, $photoPath);
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        @unlink($destination);
        send_json(["status" => "error", "message" => "Pendaftaran gagal disimpan: " . $err], 500);
    }
    $newId = $stmt->insert_id;
    $stmt->close();
    send_json([
        "status" => "success",
        "message" => "Pendaftaran berhasil dikirim. Silakan tunggu persetujuan Admin.",
        "id" => $newId,
        "event" => $event['nama_event']
    ]);
}

// Public: daftar peserta yang pendaftarannya sudah DISETUJUI untuk event tertentu.
if ($action === 'get_event_participants' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $event_id = (int)($_GET['event_id'] ?? 0);
    if ($event_id < 1) send_json(["status" => "error", "message" => "ID event tidak valid."], 400);

    $stmt = $conn->prepare("SELECT id, nama_lengkap, alias_nama, foto_path, created_at
                            FROM event_registrations
                            WHERE event_id = ? AND status = 'Disetujui'
                            ORDER BY id ASC");
    if (!$stmt) send_json(["status" => "error", "message" => $conn->error], 500);
    $stmt->bind_param('i', $event_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $participants = [];
    while ($row = $result->fetch_assoc()) $participants[] = $row;
    $stmt->close();
    send_json($participants);
}

// Semua aksi berikutnya membutuhkan login.
if ($action !== 'register_event' && $action !== 'get_registration_events') require_login_json();

if ($action === 'get_registrations' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    require_admin_json();
    $sql = "SELECT r.id, r.event_id, r.nama_lengkap, r.alias_nama, r.instagram, r.whatsapp, r.foto_path, r.status, r.created_at,
                   e.nama_event, e.cabang_olahraga, e.tanggal_pelaksanaan
            FROM event_registrations r
            LEFT JOIN events e ON e.id = r.event_id
            ORDER BY r.id DESC";
    $result = $conn->query($sql);
    if (!$result) send_json(["status" => "error", "message" => $conn->error], 500);
    $rows = [];
    while ($row = $result->fetch_assoc()) $rows[] = $row;
    send_json($rows);
}

if ($action === 'update_registration_status' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_admin_json();
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data) || empty($data['id'])) send_json(["status" => "error", "message" => "ID pendaftaran tidak valid."], 400);
    $id = (int)$data['id'];
    $status = trim((string)($data['status'] ?? ''));
    if (!in_array($status, ['Menunggu','Disetujui','Ditolak'], true)) send_json(["status" => "error", "message" => "Status tidak valid."], 400);

    $stmt = $conn->prepare("UPDATE event_registrations SET status = ? WHERE id = ?");
    $stmt->bind_param('si', $status, $id);
    if (!$stmt->execute()) send_json(["status" => "error", "message" => $stmt->error], 500);
    $stmt->close();
    send_json(["status" => "success", "message" => "Status pendaftaran menjadi $status."]);
}

if ($action === 'delete_registration' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_admin_json();
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data) || empty($data['id'])) send_json(["status" => "error", "message" => "ID pendaftaran tidak valid."], 400);
    $id = (int)$data['id'];
    $stmt = $conn->prepare("SELECT foto_path FROM event_registrations WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $id); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$row) send_json(["status" => "error", "message" => "Pendaftaran tidak ditemukan."], 404);
    $del = $conn->prepare("DELETE FROM event_registrations WHERE id = ?");
    $del->bind_param('i', $id);
    if (!$del->execute()) send_json(["status" => "error", "message" => $del->error], 500);
    $del->close();
    if (!empty($row['foto_path'])) {
        $full = __DIR__ . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $row['foto_path']);
        if (is_file($full)) @unlink($full);
    }
    send_json(["status" => "success", "message" => "Pendaftaran berhasil dihapus."]);
}

// Backward compatibility: endpoint akun lama tetap tersedia untuk Admin.
if ($action === 'get_users') {
    require_admin_json();
    $sql = "SELECT users.id, users.nama_lengkap, users.email, roles.role_name AS role, users.created_at
            FROM users LEFT JOIN roles ON users.role_id = roles.id ORDER BY users.id DESC";
    $result = $conn->query($sql);
    if (!$result) send_json(["status" => "error", "message" => $conn->error], 500);
    $users=[]; while($row=$result->fetch_assoc()) $users[]=$row; send_json($users);
}

if ($action === 'delete_user' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_admin_json();
    $data=json_decode(file_get_contents('php://input'),true); $id=(int)($data['id']??0);
    if($id<1) send_json(["status"=>"error","message"=>"ID pengguna tidak valid."],400);
    $stmt=$conn->prepare("DELETE FROM users WHERE id=?"); $stmt->bind_param('i',$id);
    if($stmt->execute()) send_json(["status"=>"success","message"=>"Pengguna berhasil dihapus"]);
    send_json(["status"=>"error","message"=>$stmt->error],500);
}

send_json(["status" => "error", "message" => "Action tidak ditemukan."], 404);
?>
